<?php

	$host="localhost";		// Nazwa hosta
	$user="root"; 				// Nazwa użytkownika - domyślnie: root
	$password=""; 			// Haslo do bazy
	$database="quiz";	 	// Nazwa bazy
	$table="pytania" 			// Nazwa tabeli
	
?>